import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import Home from './pages/Home';
import BlogListing from './pages/BlogListing';
import BlogDetail from './pages/BlogDetail';
import AdminDashboard from './pages/admin/AdminDashboard';
import PostsManager from './pages/admin/PostsManager';
import PostEditor from './pages/admin/PostEditor';
import CategoriesManager from './pages/admin/CategoriesManager';
import AuthorManager from './pages/admin/AuthorManager';
import AdminSettings from './pages/admin/AdminSettings';
import AuthorDashboard from './pages/author/AuthorDashboard';
import AdminLayout from './components/layout/AdminLayout';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Background from './components/layout/Background';

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-transparent">
      <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  if (!user) return <Navigate to="/login" replace />;

  return children;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen">
          <Background />
          <Navbar />
          <main>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Home />} />
              <Route path="/articles" element={<BlogListing />} />
              <Route path="/article/:slug" element={<BlogDetail />} />
              <Route path="/login" element={<Login />} />

              {/* Author Routes */}
              <Route 
                path="/author/dashboard" 
                element={
                  <ProtectedRoute>
                    <AuthorDashboard />
                  </ProtectedRoute>
                } 
              />

              {/* Admin Routes */}
              <Route
                path="/admin"
                element={
                  <ProtectedRoute>
                    <AdminLayout />
                  </ProtectedRoute>
                }
              >
                <Route index element={<AdminDashboard />} />
                <Route path="posts" element={<PostsManager />} />
                <Route path="posts/new" element={<PostEditor />} />
                <Route path="posts/:id/edit" element={<PostEditor />} />
                <Route path="categories" element={<CategoriesManager />} />
                <Route path="authors" element={<AuthorManager />} />
                <Route path="settings" element={<AdminSettings />} />
              </Route>

              {/* Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
