import { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import axios from 'axios';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Save, ArrowLeft, Loader2, Image as ImageIcon, Layout, Eye, ChevronRight, Check } from 'lucide-react';

const PostEditor = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditMode = Boolean(id);

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    excerpt: '',
    category: '',
    status: 'draft',
    featuredImage: '',
  });

  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(isEditMode);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (window.AOS) window.AOS.init();
    const init = async () => {
      try {
        const catRes = await axios.get('/api/categories');
        setCategories(catRes.data);

        if (!isEditMode && catRes.data.length > 0) {
          setFormData(prev => ({ ...prev, category: catRes.data[0]._id }));
        }

        if (isEditMode) {
          const postRes = await axios.get(`/api/posts/${id}`);
          const post = postRes.data;
          setFormData({
            title: post.title || '',
            content: post.content || '',
            excerpt: post.excerpt || '',
            category: post.category?._id || post.category || '',
            status: post.status || 'draft',
            featuredImage: post.featuredImage || '',
          });
        }
      } catch (err) {
        setError('Failed to fetch data');
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [id, isEditMode]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    try {
      if (isEditMode) {
        await axios.put(`/api/posts/${id}`, formData);
      } else {
        await axios.post('/api/posts', formData);
      }
      navigate('/admin/posts');
    } catch (err) {
      setError(err.response?.data?.message || 'Error saving post');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-32">
        <Loader2 className="w-12 h-12 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="space-y-10 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6" data-aos="fade-down">
        <div className="flex items-center gap-6">
          <Link to="/admin/posts" className="p-3 bg-white/5 border border-white/10 rounded-2xl text-slate-400 hover:text-white hover:border-blue-500/30 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-4xl font-extrabold tracking-tight text-white mb-1">
              {isEditMode ? 'Modify' : 'Draft'} <span className="gradient-text">Article.</span>
            </h1>
            <p className="text-slate-500 font-medium tracking-tight">Compose and configure your insurance insight.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4 w-full sm:w-auto">
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="btn-premium btn-premium-primary px-8 py-3.5 flex-1 sm:flex-none justify-center group"
          >
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5 group-hover:scale-110 transition-transform" />}
            {saving ? 'Processing...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl text-sm font-bold tracking-tight">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Editor Column */}
        <div className="lg:col-span-2 space-y-8" data-aos="fade-right">
          <div className="glass-card rounded-[2.5rem] p-8 lg:p-10 space-y-8 border-white/5">
            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1 flex items-center gap-2">
                <Layout className="w-3 h-3" /> Headline
              </label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full h-16 px-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-xl font-bold text-white placeholder:text-slate-700"
                placeholder="Article Headline..."
              />
            </div>
            
            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1 flex items-center gap-2">
                 Content Body
              </label>
              <div className="rich-editor-container">
                <ReactQuill 
                  theme="snow" 
                  value={formData.content} 
                  onChange={(val) => setFormData({ ...formData, content: val })} 
                  className="rounded-2xl overflow-hidden border-white/10"
                />
              </div>
            </div>
            
            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1 flex items-center gap-2">
                Editorial Excerpt
              </label>
              <textarea
                rows="4"
                value={formData.excerpt}
                onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                className="w-full p-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-slate-300 placeholder:text-slate-700 resize-none font-medium leading-relaxed"
                placeholder="A high-level summary for index listings..."
              />
            </div>
          </div>
        </div>

        {/* Sidebar Configuration */}
        <div className="space-y-8" data-aos="fade-left">
          <div className="glass-card rounded-[2.5rem] p-8 space-y-8 border-white/5">
            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1">Publication Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="w-full h-14 px-5 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-sm font-bold text-slate-300 appearance-none cursor-pointer"
              >
                <option value="draft">Internal Draft</option>
                <option value="published">Public Live</option>
              </select>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1">Categorization</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full h-14 px-5 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-sm font-bold text-slate-300 appearance-none cursor-pointer"
              >
                <option value="">Select Category...</option>
                {categories.map((cat) => (
                  <option key={cat._id} value={cat._id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1 flex items-center gap-2">
                <ImageIcon className="w-3 h-3" /> Featured Asset (URL)
              </label>
              <input
                type="text"
                value={formData.featuredImage}
                onChange={(e) => setFormData({ ...formData, featuredImage: e.target.value })}
                className="w-full h-14 px-5 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-xs font-mono text-slate-400 placeholder:text-slate-700"
                placeholder="https://images.unsplash.com/..."
              />
              {formData.featuredImage && (
                <div className="mt-6 rounded-2xl overflow-hidden border border-white/10 group relative aspect-video">
                  <img src={formData.featuredImage} alt="Preview" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                     <Eye className="w-6 h-6 text-white" />
                  </div>
                </div>
              )}
            </div>
            
            <div className="pt-6 border-t border-white/5">
               <div className="flex items-center gap-2 p-3 rounded-xl bg-blue-500/5 border border-blue-500/10 mb-4">
                  <Check className="w-4 h-4 text-emerald-500" />
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Auto-optimized for SEO</span>
               </div>
               <p className="text-[10px] text-slate-600 leading-relaxed font-medium">
                  Saving this article will update the real-time index across all global endpoints.
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostEditor;
