import { useState, useEffect } from 'react';
import axios from 'axios';
import { Plus, Trash2, Edit2, Loader2, Users, Search, UserCircle, UploadCloud, X, ChevronRight, CheckCircle2, ShieldCheck, Mail, Info } from 'lucide-react';

const AuthorManager = () => {
  const [authors, setAuthors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState({
    _id: '',
    name: '',
    email: '',
    bio: '',
    role: 'author',
    status: 'active',
  });
  const [photoFile, setPhotoFile] = useState(null);

  useEffect(() => {
    if (window.AOS) window.AOS.init();
    fetchAuthors();
  }, []);

  const fetchAuthors = async () => {
    try {
      const res = await axios.get('/api/authors');
      setAuthors(res.data);
    } catch (error) {
      console.error('Error fetching authors:', error);
    } finally {
      setLoading(false);
    }
  };

  const openNewModal = () => {
    setIsEditing(false);
    setFormData({ _id: '', name: '', email: '', bio: '', role: 'author', status: 'active' });
    setPhotoFile(null);
    setShowModal(true);
  };

  const openEditModal = (author) => {
    setIsEditing(true);
    setFormData({ ...author });
    setPhotoFile(null);
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    const data = new FormData();
    data.append('name', formData.name);
    data.append('email', formData.email);
    data.append('bio', formData.bio);
    data.append('role', formData.role);
    data.append('status', formData.status);
    if (photoFile) data.append('photo', photoFile);

    try {
      if (isEditing) {
        await axios.put(`/api/authors/${formData._id}`, data, { headers: { 'Content-Type': 'multipart/form-data' } });
      } else {
        await axios.post('/api/authors', data, { headers: { 'Content-Type': 'multipart/form-data' } });
      }
      await fetchAuthors();
      setShowModal(false);
    } catch (error) {
      console.error('Error saving author:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Deleting this author will unassign their posts. Continue?')) return;
    try {
      await axios.delete(`/api/authors/${id}`);
      setAuthors(authors.filter((a) => a._id !== id));
    } catch (error) {
      console.error('Error deleting author:', error);
    }
  };

  const filteredAuthors = authors.filter(a => 
    a.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    a.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6" data-aos="fade-down">
        <div>
           <div className="flex items-center gap-2 mb-2">
             <Users className="w-5 h-5 text-blue-500" />
             <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-none">Security Clearance</p>
           </div>
           <h1 className="text-4xl font-extrabold tracking-tight text-white mb-1">Author <span className="gradient-text">Matrix.</span></h1>
           <p className="text-slate-500 font-medium tracking-tight">Manage editorial identities and cryptographic access levels.</p>
        </div>
        <button 
          onClick={openNewModal}
          className="btn-premium btn-premium-primary px-6 py-3.5 text-sm group"
        >
          <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform" />
          Onboard New Author
        </button>
      </div>

      <div className="glass-card rounded-[2.5rem] border-white/5 overflow-hidden" data-aos="fade-up">
        <div className="p-8 border-b border-white/5 bg-white/[0.01]">
          <div className="relative w-full md:max-w-md group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
            <input
              type="text"
              placeholder="Filter by name or secure email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-14 pl-14 pr-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-sm font-medium focus:bg-white/10"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          {loading ? (
             <div className="py-20 flex flex-col items-center justify-center">
               <Loader2 className="w-12 h-12 animate-spin text-blue-600 mb-6" />
               <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Querying Personnel Database...</p>
             </div>
          ) : (
             <table className="w-full text-left">
               <thead>
                 <tr className="border-b border-white/5 bg-white/[0.02]">
                   <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Author Profiling</th>
                   <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Access Credentials</th>
                   <th className="px-8 py-5 text-right text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Operation</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                 {filteredAuthors.map((author, idx) => (
                   <tr key={author._id} className="hover:bg-white/[0.03] transition-colors group" data-aos="fade-up" data-aos-delay={idx * 50}>
                     <td className="px-8 py-6">
                       <div className="flex items-center gap-4">
                         <div className="w-14 h-14 rounded-2xl border-2 border-white/5 overflow-hidden bg-slate-800 p-0.5 group-hover:border-blue-500/30 transition-all">
                           {author.photo ? (
                             <img src={`${author.photo}`} alt="avatar" className="w-full h-full rounded-xl object-cover" />
                           ) : (
                             <div className="w-full h-full rounded-xl flex items-center justify-center">
                                <UserCircle className="w-8 h-8 text-slate-600" />
                             </div>
                           )}
                         </div>
                         <div>
                           <div className="text-base font-bold text-white mb-0.5 group-hover:text-blue-400 transition-colors">{author.name}</div>
                           <div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">{author.status === 'active' ? 'SECURE' : 'LOCKED'}</div>
                         </div>
                       </div>
                     </td>
                     <td className="px-8 py-6">
                        <div className="flex items-center gap-2 mb-2">
                           <ShieldCheck className="w-3 h-3 text-blue-500" />
                           <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">RANK: {author.role}</span>
                        </div>
                        <div className="flex items-center gap-2">
                           <Mail className="w-3 h-3 text-slate-600" />
                           <span className="text-sm font-medium text-slate-400">{author.email}</span>
                        </div>
                     </td>
                     <td className="px-8 py-6 text-right">
                       <div className="flex justify-end gap-2">
                         <button 
                           onClick={() => openEditModal(author)} 
                           className="p-3 rounded-xl bg-white/5 border border-white/5 text-slate-400 hover:text-blue-400 hover:border-blue-500/30 transition-all"
                           title="Edit Credentials"
                         >
                           <Edit2 className="w-4 h-4" />
                         </button>
                         <button 
                           onClick={() => handleDelete(author._id)} 
                           className="p-3 rounded-xl bg-white/5 border border-white/5 text-slate-400 hover:text-red-400 hover:border-red-500/30 transition-all"
                           title="Revoke Access"
                         >
                           <Trash2 className="w-4 h-4" />
                         </button>
                       </div>
                     </td>
                   </tr>
                 ))}
                 {filteredAuthors.length === 0 && (
                   <tr>
                     <td colSpan="3" className="py-20 text-center text-slate-600">
                        <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6">
                          <Users className="w-8 h-8 opacity-20" />
                        </div>
                        No personnel records detected in local sector.
                     </td>
                   </tr>
                 )}
               </tbody>
             </table>
          )}
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-[#0A0A0F]/90 backdrop-blur-xl flex items-center justify-center p-6 z-[2000] animate-in fade-in duration-300">
          <form onSubmit={handleSubmit} className="glass-card rounded-[3rem] p-10 w-full max-w-2xl border-white/10 shadow-2xl relative" data-aos="zoom-in">
             <button type="button" onClick={() => setShowModal(false)} className="absolute top-8 right-8 text-slate-600 hover:text-white transition-colors">
                <X className="w-6 h-6" />
             </button>

             <div className="flex items-center gap-4 mb-10">
                <div className="w-12 h-12 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center">
                   <ShieldCheck className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <h2 className="text-3xl font-extrabold text-white leading-none">{isEditing ? 'Modify' : 'Onboard'} Author</h2>
                  <p className="text-xs font-bold text-slate-600 uppercase tracking-widest mt-1">Identity Authorization Protocol</p>
                </div>
             </div>
             
             <div className="grid grid-cols-2 gap-6 mb-6">
               <div className="space-y-2">
                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Legal Designation</label>
                 <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full h-14 px-6 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-slate-700 font-bold" placeholder="First Last" />
               </div>
               <div className="space-y-2">
                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Secure Email</label>
                 <input type="email" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full h-14 px-6 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-slate-700 font-bold" placeholder="name@insureiq.ai" />
               </div>
             </div>

             <div className="space-y-2 mb-6">
               <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Personnel Dossier (Bio)</label>
               <textarea rows="3" value={formData.bio} onChange={e => setFormData({...formData, bio: e.target.value})} className="w-full p-6 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-slate-300 placeholder:text-slate-700 font-medium resize-none" placeholder="Professional history and expertise..."></textarea>
             </div>

             <div className="grid grid-cols-2 gap-6 mb-8">
               <div className="space-y-2">
                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Assign Rank</label>
                 <select value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})} className="w-full h-14 px-5 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-sm font-bold text-slate-300 appearance-none cursor-pointer">
                   <option value="author">AUTHOR</option>
                   <option value="editor">EDITOR</option>
                   <option value="admin">ADMIN</option>
                 </select>
               </div>
               <div className="space-y-2">
                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Account Secret (Password)</label>
                 <input 
                   type="password" 
                   value={formData.password || ''} 
                   onChange={e => setFormData({...formData, password: e.target.value})} 
                   className="w-full h-14 px-6 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-slate-700 font-bold" 
                   placeholder={isEditing ? "Leave blank to keep current" : "Set password"} 
                 />
               </div>
             </div>

             <div className="grid grid-cols-1 gap-6 mb-8">
               <div className="space-y-2">
                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Clearance Status</label>
                 <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value})} className="w-full h-14 px-5 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-sm font-bold text-slate-300 appearance-none cursor-pointer">
                   <option value="active">AUTHORIZE</option>
                   <option value="inactive">REVOKE</option>
                 </select>
               </div>
             </div>

             <div className="mb-10 p-6 rounded-3xl bg-white/5 border border-white/5 relative group cursor-pointer hover:border-blue-500/30 transition-all">
                <input type="file" accept="image/*" onChange={e => setPhotoFile(e.target.files[0])} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" />
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-blue-600/10 transition-colors">
                      <UploadCloud className="w-6 h-6 text-slate-500 group-hover:text-blue-500" />
                   </div>
                   <div>
                     <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Upload Identification Image</p>
                     <p className="text-xs font-bold text-white uppercase truncate max-w-[300px]">
                        {photoFile ? photoFile.name : 'Select Avatar Segment'}
                     </p>
                   </div>
                </div>
             </div>

             <div className="flex gap-4">
                <button type="submit" disabled={saving} className="btn-premium btn-premium-primary flex-1 h-14 text-sm justify-center">
                  {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                  {saving ? 'Processing Authorization...' : 'Finalize Authorization'}
                </button>
             </div>
             
             <div className="mt-8 flex items-center justify-center gap-2 text-[10px] font-bold text-slate-700 uppercase tracking-[0.2em]">
                <Info className="w-3 h-3" />
                <span>All changes are logged in the secure audit trail.</span>
             </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default AuthorManager;
