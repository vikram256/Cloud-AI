import { useState, useEffect } from 'react';
import { Plus, Trash2, Tag, Search, Loader2, Database, ChevronRight, X, Hash } from 'lucide-react';
import axios from 'axios';

const CategoriesManager = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCat, setNewCat] = useState({ name: '', description: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (window.AOS) window.AOS.init();
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const res = await axios.get('/api/categories');
      setCategories(res.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this category?')) return;
    try {
      await axios.delete(`/api/categories/${id}`);
      setCategories(categories.filter((cat) => cat._id !== id));
    } catch (error) {
      console.error('Error deleting category:', error);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!newCat.name) return;
    setSaving(true);
    try {
      const res = await axios.post('/api/categories', newCat);
      setCategories([...categories, res.data]);
      setShowAddForm(false);
      setNewCat({ name: '', description: '' });
    } catch (error) {
      console.error('Error creating category:', error);
    } finally {
      setSaving(false);
    }
  };

  const filteredCategories = categories.filter(c => 
    c.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.slug?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6" data-aos="fade-down">
        <div>
           <div className="flex items-center gap-2 mb-2">
             <Database className="w-5 h-5 text-blue-500" />
             <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-none">Taxonomy Management</p>
           </div>
           <h1 className="text-4xl font-extrabold tracking-tight text-white mb-1">Knowledge <span className="gradient-text">Silis.</span></h1>
           <p className="text-slate-500 font-medium tracking-tight">Organize publications into logical insurance verticals.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className={`btn-premium px-6 py-3.5 text-sm transition-all ${showAddForm ? 'btn-premium-glass border-red-500/30 text-red-400' : 'btn-premium-primary'}`}
        >
          {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showAddForm ? 'Cancel Creation' : 'Register New Vertical'}
        </button>
      </div>

      {showAddForm && (
        <form onSubmit={handleCreate} className="glass-card rounded-[2.5rem] p-8 lg:p-10 border-blue-500/20 animate-in fade-in slide-in-from-top-4" data-aos="zoom-in">
          <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
             <Plus className="w-6 h-6 text-blue-500" />
             New Vertical Configuration
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Vertical Identity</label>
              <input 
                type="text" 
                required 
                value={newCat.name}
                onChange={e => setNewCat({...newCat, name: e.target.value})}
                className="w-full h-14 px-6 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-slate-700 font-bold"
                placeholder="e.g. Life Insurance"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Vertical Scope</label>
              <input 
                type="text" 
                value={newCat.description}
                onChange={e => setNewCat({...newCat, description: e.target.value})}
                className="w-full h-14 px-6 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-slate-700 font-bold"
                placeholder="Brief thematic scope"
              />
            </div>
          </div>
          <button 
            type="submit" 
            disabled={saving}
            className="btn-premium btn-premium-primary px-10 py-4 h-14"
          >
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChevronRight className="w-5 h-5" />}
            {saving ? 'Processing...' : 'Authorize Vertical'}
          </button>
        </form>
      )}

      <div className="glass-card rounded-[2.5rem] border-white/5 overflow-hidden" data-aos="fade-up">
        <div className="p-8 border-b border-white/5 bg-white/[0.01]">
          <div className="relative w-full md:max-w-md group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
            <input
              type="text"
              placeholder="Search active knowledge hubs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-14 pl-14 pr-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-sm font-medium focus:bg-white/10"
            />
          </div>
        </div>

        <div className="p-8 lg:p-10">
          {loading ? (
             <div className="flex flex-col items-center justify-center py-20">
               <Loader2 className="w-12 h-12 animate-spin text-blue-600 mb-6" />
               <p className="text-xs font-bold uppercase tracking-widest text-slate-600">Querying Taxonomy Records...</p>
             </div>
          ) : filteredCategories.length === 0 ? (
             <div className="text-center py-20 text-slate-500 group">
               <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6">
                 <Tag className="w-8 h-8 opacity-20" />
               </div>
               No taxonomy segments detected in local sector.
             </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredCategories.map((category, idx) => (
                <div 
                  key={category._id} 
                  className="group relative flex flex-col justify-between p-8 bg-white/5 border border-white/5 rounded-3xl hover:border-blue-500/30 hover:bg-white/10 transition-all group overflow-hidden"
                  data-aos="fade-up"
                  data-aos-delay={idx * 50}
                >
                  <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                    <Hash className="w-16 h-16" />
                  </div>
                  
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-10">
                       <span className="inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase bg-blue-500/10 border border-blue-500/20 text-blue-400">
                         SEGMENT {idx + 1}
                       </span>
                       <button 
                         onClick={() => handleDelete(category._id)} 
                         className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                         title="Archive Segment"
                       >
                         <Trash2 className="w-4 h-4" />
                       </button>
                    </div>
                    <h3 className="text-2xl font-extrabold text-white mb-1 group-hover:text-blue-400 transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-xs font-mono font-bold text-slate-600 mb-2 uppercase tracking-tighter">/{category.slug}</p>
                    <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                       {category.description || 'Global insurance taxonomy segment.'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoriesManager;
