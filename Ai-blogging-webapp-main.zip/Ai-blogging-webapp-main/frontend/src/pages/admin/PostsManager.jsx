import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Search, Filter, Loader2, FileText, ChevronRight, Globe, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';

const PostsManager = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (window.AOS) window.AOS.init();
    fetchPosts();
  }, [user]);

  const fetchPosts = async () => {
    try {
      const res = await axios.get('/api/posts');
      let data = Array.isArray(res.data) ? res.data : [];
      if (user && user.role !== 'admin') {
        data = data.filter(p => p.author_id === user._id);
      }
      setPosts(data);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    try {
      await axios.delete(`/api/posts/${id}`);
      setPosts(posts.filter((post) => post._id !== id));
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };

  const filteredPosts = posts.filter(p => 
    p.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6" data-aos="fade-down">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight text-white mb-2">Content <span className="gradient-text">Repository.</span></h1>
          <p className="text-slate-500 font-medium tracking-tight">Manage, edit, and orchestrate your insurance publications.</p>
        </div>
        <Link to="/admin/posts/new" className="btn-premium btn-premium-primary px-6 py-3.5 text-sm group">
          <Plus className="w-4 h-4" />
          Create New Article
          <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>

      <div className="glass-card rounded-[2.5rem] border-white/5 overflow-hidden" data-aos="fade-up">
        <div className="p-6 lg:p-8 border-b border-white/5 flex flex-col md:flex-row gap-6 justify-between items-center">
          <div className="relative w-full md:max-w-md group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
            <input
              type="text"
              placeholder="Filter by title or category..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-12 pl-12 pr-4 bg-white/5 border border-white/10 rounded-xl outline-none focus:border-blue-500/50 transition-all text-sm font-medium focus:bg-white/10"
            />
          </div>
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button className="flex-1 md:flex-none h-12 px-6 border border-white/10 bg-white/5 text-slate-300 text-xs font-bold uppercase tracking-widest rounded-xl hover:bg-white/10 hover:border-white/20 transition-all flex items-center justify-center gap-2">
              <Filter className="w-4 h-4" />
              Advanced Filters
            </button>
          </div>
        </div>

        <div className="overflow-x-auto min-h-[400px]">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-white/5 bg-white/[0.02]">
                <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Article Information</th>
                <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Visibility Status</th>
                <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Classification</th>
                <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Timestamp</th>
                <th className="px-8 py-5 text-right text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr>
                  <td colSpan="5" className="px-8 py-20 text-center text-slate-500">
                    <Loader2 className="w-10 h-10 animate-spin mx-auto text-blue-500 mb-4" />
                    <p className="text-sm font-bold uppercase tracking-widest">Querying database...</p>
                  </td>
                </tr>
              ) : filteredPosts.length === 0 ? (
                <tr>
                  <td colSpan="5" className="px-8 py-20 text-center text-slate-500 font-medium">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6">
                      <FileText className="w-8 h-8 opacity-20" />
                    </div>
                    No records found matching your current parameters.
                  </td>
                </tr>
              ) : (
                filteredPosts.map((post, idx) => (
                  <tr key={post._id} className="hover:bg-white/[0.03] transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 flex items-center justify-center flex-shrink-0">
                          <FileText className="w-5 h-5 text-slate-400 group-hover:text-blue-400 transition-colors" />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors truncate max-w-[300px] mb-0.5">{post.title}</div>
                          <div className="text-[10px] font-mono text-slate-600 tracking-tighter truncate max-w-[300px]">{post.slug}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg border text-[10px] font-bold tracking-widest uppercase ${
                        post.status === 'published' 
                          ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                          : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                      }`}>
                        {post.status === 'published' ? <Globe className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                        {post.status?.toUpperCase() || 'DRAFT'}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className="text-sm font-bold text-slate-300">
                        {post.category?.name || 'Uncategorized'}
                      </span>
                    </td>
                    <td className="px-8 py-6 whitespace-nowrap">
                      <div className="text-xs font-bold text-slate-400">
                        {new Date(post.createdAt || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex justify-end gap-2">
                        <Link 
                          to={`/admin/posts/${post._id}/edit`} 
                          className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-blue-400 hover:bg-blue-600/10 hover:border-blue-500/30 transition-all shadow-sm"
                          title="Edit Entry"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Link>
                        <button 
                          onClick={() => handleDelete(post._id)} 
                          className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-red-400 hover:bg-red-600/10 hover:border-red-500/30 transition-all shadow-sm"
                          title="Delete Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="p-8 border-t border-white/5 bg-white/[0.01] flex items-center justify-between">
          <div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest pl-2">
             Records: <span className="text-slate-400">{filteredPosts.length}</span>
          </div>
          <div className="flex gap-2">
             <button className="h-10 px-6 rounded-xl border border-white/5 bg-white/5 text-slate-600 text-xs font-bold uppercase transition-all" disabled>Previous</button>
             <button className="h-10 px-6 rounded-xl border border-white/10 bg-white/5 text-slate-400 hover:bg-white/10 text-xs font-bold uppercase transition-all">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostsManager;
