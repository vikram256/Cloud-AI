import { TrendingUp, Activity, Users, FileText, ChevronRight, Zap } from 'lucide-react';
import { useEffect } from 'react';

const AdminDashboard = () => {
  useEffect(() => {
    if (window.AOS) window.AOS.init();
  }, []);

  const stats = [
    { name: 'Total Articles', value: '1,248', icon: FileText, change: '+12%', changeType: 'increase' },
    { name: 'Active Categories', value: '8', icon: Activity, change: '+1', changeType: 'increase' },
    { name: 'Monthly Readers', value: '52.4K', icon: Users, change: '+8.2%', changeType: 'increase' },
    { name: 'Avg. Engagement', value: '4m 12s', icon: TrendingUp, change: '-2.1%', changeType: 'decrease' },
  ];

  const recentActions = [
    { text: 'Updated article: "Understanding Auto Insurance Limits"', time: '2 hrs ago', type: 'update' },
    { text: 'Created category: "Homeowner Policies"', time: '5 hrs ago', type: 'create' },
    { text: 'Published article: "10 Life Insurance Myths Debunked"', time: '1 day ago', type: 'publish' },
    { text: 'New Author profile created: "Sarah Jenkins"', time: '2 days ago', type: 'create' },
  ];

  return (
    <div className="space-y-12">
      <header data-aos="fade-right">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-blue-600/10 border border-blue-500/20 flex items-center justify-center">
            <Zap className="w-4 h-4 text-blue-500 animate-pulse" />
          </div>
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] leading-none">Security Monitoring Active</p>
        </div>
        <h1 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-2">Systems Overview</h1>
        <p className="text-slate-500 font-medium">Real-time performance metrics for the InsureIQ network.</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((item, idx) => (
          <div
            key={item.name}
            className="glass-card rounded-[2rem] p-8 group hover:-translate-y-1 transition-all"
            data-aos="fade-up"
            data-aos-delay={idx * 50}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="p-3 rounded-2xl bg-white/5 group-hover:bg-blue-600/10 border border-white/5 group-hover:border-blue-500/20 transition-all">
                <item.icon className="h-6 w-6 text-slate-400 group-hover:text-blue-400 transition-colors" />
              </div>
              <span className={`text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full border ${
                item.changeType === 'increase' 
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                  : 'bg-red-500/10 border-red-500/20 text-red-400'
              }`}>
                {item.change}
              </span>
            </div>
            <dt className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-1">{item.name}</dt>
            <dd className="text-3xl font-extrabold text-white tracking-tight">{item.value}</dd>
          </div>
        ))}
      </div>

      {/* Activity Feed */}
      <div className="glass-card rounded-[2.5rem] p-8 lg:p-12" data-aos="fade-up">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-2xl font-bold text-white tracking-tight">System Activity</h2>
          <button className="text-[10px] font-bold text-blue-400 uppercase tracking-widest hover:text-white transition-colors flex items-center gap-1">
            View Full Log <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="space-y-4">
          {recentActions.map((action, idx) => (
            <div 
              key={idx} 
              className="group flex items-center justify-between p-5 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 hover:bg-white/[0.08] transition-all cursor-default"
              data-aos="fade-up"
              data-aos-delay={200 + (idx * 50)}
            >
              <div className="flex items-center gap-4">
                <div className={`w-2 h-2 rounded-full ${
                  action.type === 'publish' ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' :
                  action.type === 'create' ? 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]' :
                  'bg-slate-500'
                }`}></div>
                <span className="text-sm font-medium text-slate-300 group-hover:text-white transition-colors">{action.text}</span>
              </div>
              <span className="text-[10px] font-mono text-slate-600 font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                {action.time}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Health Check */}
      <div className="flex flex-col md:flex-row gap-6" data-aos="fade-up">
        <div className="flex-1 glass-card rounded-3xl p-8 flex items-center gap-6 border-emerald-500/10">
          <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center flex-shrink-0">
            <Activity className="w-6 h-6 text-emerald-500" />
          </div>
          <div>
             <h4 className="text-white font-bold mb-0.5">Api Engine Status</h4>
             <p className="text-xs text-slate-500">Latency: 24ms • Uptime: 99.98%</p>
          </div>
          <span className="ml-auto text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Normal</span>
        </div>
        <div className="flex-1 glass-card rounded-3xl p-8 flex items-center gap-6 border-blue-500/10">
          <div className="w-12 h-12 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0">
            <Users className="w-6 h-6 text-blue-500" />
          </div>
          <div>
             <h4 className="text-white font-bold mb-0.5">User Connectivity</h4>
             <p className="text-xs text-slate-500">14 Active Sessions • Worldwide</p>
          </div>
          <span className="ml-auto text-[10px] font-bold text-blue-500 uppercase tracking-widest">Secure</span>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
