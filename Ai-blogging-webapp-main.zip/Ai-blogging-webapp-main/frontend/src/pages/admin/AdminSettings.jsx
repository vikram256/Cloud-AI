import { useState, useEffect } from 'react';
import axios from 'axios';
import { AlertCircle, Loader2, Database, Trash2, ShieldAlert, ChevronRight, CheckCircle2, Info } from 'lucide-react';

const AdminSettings = () => {
  const [resetConfirm, setResetConfirm] = useState('');
  const [isResetting, setIsResetting] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (window.AOS) window.AOS.init();
  }, []);

  const handleReset = async (e) => {
    e.preventDefault();
    if (resetConfirm !== 'RESET') return;
    
    setIsResetting(true);
    setMessage('');

    try {
      const res = await axios.post('/admin/reset');
      setMessage(res.data.message || 'Platform successfully reset to a clean state!');
      setResetConfirm('');
    } catch (error) {
      setMessage('Failed to reset platform data. Please try again.');
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="space-y-12">
      <header data-aos="fade-right">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-red-600/10 border border-red-500/20 flex items-center justify-center">
            <ShieldAlert className="w-4 h-4 text-red-500" />
          </div>
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] leading-none">Security Override Authorization</p>
        </div>
        <h1 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-2">System <span className="text-red-500">Parameters.</span></h1>
        <p className="text-slate-500 font-medium tracking-tight">Manage the core integrity and administrative states of the InsureIQ network.</p>
      </header>

      {/* Danger Zone Card */}
      <div className="glass-card rounded-[3rem] p-8 lg:p-14 border-red-500/20 relative overflow-hidden" data-aos="fade-up">
        {/* Subtle Red Glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/5 blur-[100px] pointer-events-none"></div>
        
        <div className="flex flex-col lg:flex-row items-start gap-12">
          <div className="lg:max-w-md">
            <div className="w-16 h-16 rounded-[1.5rem] bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-8">
              <AlertCircle className="w-8 h-8 text-red-500 animate-pulse" />
            </div>
            <h3 className="text-3xl font-extrabold text-white mb-6">Hard Reset Protocol</h3>
            <p className="text-slate-500 text-lg leading-relaxed mb-10">
              This action is destructive and irreversible. It will wipe all blog posts, authors, and user-generated categories. 
              Only core defaults and your admin credentials will be restored. Media files will also be wiped.
            </p>
            <div className="flex items-center gap-3 p-4 rounded-xl bg-red-500/5 border border-red-500/10 text-[10px] font-bold text-red-400 uppercase tracking-widest">
               <Info className="w-4 h-4" />
               Critical Override: Use with extreme caution.
            </div>
          </div>

          <div className="w-full lg:flex-1">
             <form onSubmit={handleReset} className="glass-card bg-white/5 p-8 lg:p-10 rounded-[2.5rem] border-white/5 space-y-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1">
                    Authorization Phrase
                  </label>
                  <p className="text-xs text-slate-400 mb-2">Type <strong className="text-red-400 font-mono tracking-widest">RESET</strong> below to authorize hard reset:</p>
                  <input
                    type="text"
                    value={resetConfirm}
                    onChange={(e) => setResetConfirm(e.target.value)}
                    placeholder="ENTER PHRASE"
                    className="w-full h-16 px-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-red-500/50 transition-all text-xl font-black text-white placeholder:text-slate-800 uppercase font-mono tracking-widest"
                  />
                </div>

                <button
                  type="submit"
                  disabled={resetConfirm !== 'RESET' || isResetting}
                  className={`btn-premium w-full h-16 text-sm justify-center group transition-all ${
                    resetConfirm === 'RESET' 
                      ? 'bg-red-600 border-red-500 shadow-xl shadow-red-900/40 text-white' 
                      : 'bg-white/5 border-white/10 text-slate-600'
                  }`}
                >
                  {isResetting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Trash2 className="w-5 h-5 group-hover:scale-110 transition-transform" />}
                  {isResetting ? 'EXECUTING RESET...' : 'AUTHORIZE HARD RESET'}
                </button>
                
                {message && (
                  <div className={`mt-10 p-5 rounded-2xl flex items-center gap-4 border animate-in slide-in-from-top-2 ${message.includes('success') ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                      {message.includes('success') ? <CheckCircle2 className="w-5 h-5" /> : <Database className="w-5 h-5" />}
                    </div>
                    <div>
                       <p className="text-[10px] font-bold uppercase tracking-widest mb-0.5">Operation Result</p>
                       <p className="text-sm font-bold">{message}</p>
                    </div>
                  </div>
                )}
             </form>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6" data-aos="fade-up">
         {[
           { label: 'System Uptime', value: '99.98%', icon: Database },
           { label: 'Security Patch', value: 'v2026.1', icon: ShieldAlert },
           { label: 'Node Health', value: 'Optimal', icon: CheckCircle2 }
         ].map((item, i) => (
           <div key={i} className="glass-card p-6 rounded-3xl flex items-center gap-4">
              <div className="p-3 bg-white/5 rounded-xl border border-white/10">
                 <item.icon className="w-4 h-4 text-slate-500" />
              </div>
              <div>
                 <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest mb-0.5">{item.label}</p>
                 <p className="text-sm font-bold text-white">{item.value}</p>
              </div>
           </div>
         ))}
      </div>
    </div>
  );
};

export default AdminSettings;
