import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, ShieldCheck, HeartPulse, Home as HomeIcon, 
  Car, Loader2, Bot, Search, ChevronDown, CheckCircle2 
} from 'lucide-react';
import axios from 'axios';

const insights = [
  "Term life insurance is the most cost-efficient option for Indian families under 45 with dependents.",
  "A family floater health plan of ₹15 lakh is recommended for metro city residents in 2026.",
  "Always check the Claim Settlement Ratio before buying any insurance — aim for above 95%.",
  "Buying health insurance before age 30 significantly reduces your premium for the next 20 years."
];

const placeholders = [
  "Search health insurance for family...",
  "Compare term vs whole life plans...",
  "Best auto insurance 2026...",
  "How to file an insurance claim..."
];

const categories = [
  { name: 'Life Insurance', icon: HeartPulse, color: '#EF4444', delay: 100 },
  { name: 'Health', icon: ShieldCheck, color: '#10B981', delay: 200 },
  { name: 'Auto', icon: Car, color: '#3B82F6', delay: 300 },
  { name: 'Homeowners', icon: HomeIcon, color: '#8B5CF6', delay: 400 }
];

const Home = () => {
  const [latestPosts, setLatestPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentInsight, setCurrentInsight] = useState(0);
  const [searchPlaceholder, setSearchPlaceholder] = useState(0);
  const statsRef = useRef(null);
  const [statsStarted, setStatsStarted] = useState(false);

  useEffect(() => {
    // AOS Init
    if (window.AOS) {
      window.AOS.init({ duration: 800, once: true, offset: 50 });
    }

    // Lucide Icons (force re-render if needed, but react-lucide handles it)
    
    const fetchLatest = async () => {
      try {
        const res = await axios.get('/api/posts');
        const published = res.data.filter(p => p.status === 'published' || !p.status);
        setLatestPosts(published.slice(0, 3));
      } catch (error) {
        console.error('Error fetching latest posts', error);
      } finally {
        setLoading(false);
      }
    };
    fetchLatest();

    // AI Insight cycling
    const insightInterval = setInterval(() => {
      setCurrentInsight(prev => (prev + 1) % insights.length);
    }, 6000);

    // Placeholder cycling
    const placeholderInterval = setInterval(() => {
      setSearchPlaceholder(prev => (prev + 1) % placeholders.length);
    }, 3000);

    // Stats Intersection Observer
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !statsStarted) {
        setStatsStarted(true);
        startCounting();
      }
    }, { threshold: 0.5 });

    if (statsRef.current) observer.observe(statsRef.current);

    return () => {
      clearInterval(insightInterval);
      clearInterval(placeholderInterval);
      observer.disconnect();
    };
  }, [statsStarted]);

  const startCounting = () => {
    if (window.countUp) {
      document.querySelectorAll('.stat-number').forEach(el => {
        const target = parseInt(el.dataset.target);
        const countUp = new window.countUp.CountUp(el, target, {
          duration: 2.5, useEasing: true
        });
        countUp.start();
      });
    }
  };

  return (
    <div className="min-h-screen text-white pt-16">
      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center text-center px-6 py-20 lg:py-32 overflow-hidden">
        <div 
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-blue-500/20 bg-blue-500/5 mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700"
          style={{ animationDelay: '200ms' }}
        >
          <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
          <span className="text-[10px] font-mono tracking-widest text-blue-400 uppercase">AI-Powered Insurance Knowledge Hub</span>
        </div>

        <h1 className="text-5xl lg:text-8xl font-extrabold tracking-tight leading-[1.1] mb-8">
          <span className="block animate-in fade-in slide-in-from-bottom-8 duration-700" style={{ animationDelay: '400ms' }}>Understand Insurance.</span>
          <span className="block gradient-text animate-in fade-in slide-in-from-bottom-8 duration-700" style={{ animationDelay: '600ms' }}>Protect What Matters.</span>
        </h1>

        <p 
          className="text-lg text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700"
          style={{ animationDelay: '800ms' }}
        >
          Expert insights on Life, Health, Auto, and Home Insurance — written for real Indian families and modern professionals.
        </p>

        <div 
          className="flex flex-col sm:flex-row items-center gap-4 animate-in fade-in slide-in-from-bottom-8 duration-700"
          style={{ animationDelay: '1000ms' }}
        >
          <Link to="/articles" className="btn-premium btn-premium-primary text-base px-8 py-4">
            Explore Articles
            <ArrowRight className="w-5 h-5" />
          </Link>
          <Link to="/about" className="btn-premium btn-premium-glass text-base px-8 py-4">
            Learn About Us
          </Link>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-40">
          <ChevronDown className="w-6 h-6" />
        </div>
      </section>

      {/* Stats Bar */}
      <section ref={statsRef} className="max-w-7xl mx-auto px-6 mb-24" data-aos="fade-up">
        <div className="glass-card rounded-[2rem] p-8 md:p-12 flex flex-wrap justify-between items-center gap-8">
          <div className="flex-1 min-w-[150px] text-center">
            <div className="text-4xl font-bold mb-1">
              <span className="stat-number" data-target="150">0</span>
              <span className="text-blue-500">+</span>
            </div>
            <div className="text-xs text-slate-500 uppercase tracking-widest font-semibold">Articles Published</div>
          </div>
          <div className="hidden md:block w-px h-12 bg-white/5"></div>
          <div className="flex-1 min-w-[150px] text-center">
            <div className="text-4xl font-bold mb-1">
              <span className="stat-number" data-target="8">0</span>
            </div>
            <div className="text-xs text-slate-500 uppercase tracking-widest font-semibold">Insurance Categories</div>
          </div>
          <div className="hidden md:block w-px h-12 bg-white/5"></div>
          <div className="flex-1 min-w-[150px] text-center">
            <div className="text-4xl font-bold mb-1">
              <span className="stat-number" data-target="50">0</span>
              <span className="text-blue-500">K+</span>
            </div>
            <div className="text-xs text-slate-500 uppercase tracking-widest font-semibold">Monthly Readers</div>
          </div>
          <div className="hidden md:block w-px h-12 bg-white/5"></div>
          <div className="flex-1 min-w-[150px] text-center">
            <div className="text-4xl font-bold mb-1">
              <span className="stat-number" data-target="99">0</span>
              <span className="text-blue-500">%</span>
            </div>
            <div className="text-xs text-slate-500 uppercase tracking-widest font-semibold">Free to Read</div>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="max-w-4xl mx-auto px-6 mb-32" data-aos="fade-up">
        <div className="relative group">
          <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
          </div>
          <input 
            type="text" 
            placeholder={placeholders[searchPlaceholder]}
            className="w-full h-16 pl-16 pr-32 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-lg font-medium tracking-tight placeholder:text-slate-600 focus:bg-white/10"
          />
          <button className="absolute right-3 top-3 bottom-3 px-6 bg-blue-600 hover:bg-blue-500 rounded-xl font-bold text-sm transition-colors active:scale-95">
            Search
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mt-6 justify-center">
          {['#HealthInsurance', '#TermLife', '#FamilyCover', '#CarInsurance'].map(tag => (
            <span key={tag} className="px-3 py-1 rounded-full text-[10px] font-bold tracking-wider text-slate-500 bg-white/5 border border-white/5 hover:border-white/20 transition-colors cursor-pointer capitalize">
              {tag}
            </span>
          ))}
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <div className="flex items-center justify-between mb-8" data-aos="fade-right">
              <h2 className="text-3xl font-bold tracking-tight">Latest Insights</h2>
              <Link to="/articles" className="text-sm font-bold text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1 group">
                View Collection
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            {loading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="w-10 h-10 animate-spin text-blue-500" />
              </div>
            ) : (
              <div className="space-y-8">
                {latestPosts.map((post, idx) => (
                  <article key={post._id} className="glass-card rounded-3xl p-6 group flex flex-col md:flex-row gap-8" data-aos="fade-up" data-aos-delay={idx * 100}>
                    <div className="w-full md:w-64 h-48 rounded-2xl overflow-hidden bg-slate-800 flex-shrink-0 relative">
                      {post.featuredImage ? (
                        <img src={post.featuredImage} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-800 to-slate-900">
                          <ShieldCheck className="w-12 h-12 text-slate-700" />
                        </div>
                      )}
                      <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-blue-600/90 backdrop-blur-md text-[10px] font-bold tracking-widest text-white uppercase shadow-lg">
                        {post.category?.name || 'Policy'}
                      </span>
                    </div>
                    <div className="flex flex-col justify-between py-2">
                       <div>
                          <h3 className="text-2xl font-bold mb-4 group-hover:text-blue-400 transition-colors">
                            <Link to={`/article/${post.slug}`}>{post.title}</Link>
                          </h3>
                          <p className="text-slate-400 leading-relaxed line-clamp-2 text-sm">
                            {post.excerpt || post.content?.replace(/<[^>]+>/g, '').substring(0, 150)}
                          </p>
                       </div>
                       <div className="flex items-center justify-between mt-auto pt-6 border-t border-white/5">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center overflow-hidden">
                              <img src={`https://i.pravatar.cc/32?img=${idx + 1}`} alt="Avatar" />
                            </div>
                            <span className="text-xs font-bold text-slate-300">Policy Expert</span>
                          </div>
                          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                            {new Date(post.createdAt || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </span>
                       </div>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <aside className="space-y-12">
            {/* AI Widget */}
            <div className="glass-card rounded-3xl p-8 border-blue-500/10 relative overflow-hidden" data-aos="fade-left">
              <div className="absolute top-0 right-0 p-4 opacity-5">
                <Bot className="w-24 h-24" />
              </div>
              <div className="flex items-center gap-2 mb-6">
                <Bot className="w-5 h-5 text-blue-500" />
                <span className="text-[10px] font-bold tracking-widest uppercase text-slate-400">AI Daily Insight</span>
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
              </div>
              <p className="text-lg font-medium leading-relaxed mb-6 text-white min-h-[100px] animate-in fade-in transition-opacity duration-1000">
                {insights[currentInsight]}
              </p>
              <div className="flex items-center justify-between text-[10px] font-mono tracking-widest text-slate-600">
                <span>UPDATED LIVE</span>
                <span>2026 EDITION</span>
              </div>
            </div>

            {/* Categories */}
            <div data-aos="fade-left" data-aos-delay="200">
              <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-blue-500" />
                Key Topics
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {categories.map((cat, i) => (
                  <Link 
                    key={cat.name} 
                    to="/articles" 
                    className="glass-card p-4 rounded-2xl flex items-center gap-4 hover:border-blue-500/30 transition-all group"
                  >
                    <div className="p-3 rounded-xl bg-white/5 group-hover:bg-blue-600/10 transition-colors">
                      <cat.icon className="w-5 h-5" style={{ color: cat.color }} />
                    </div>
                    <span className="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">{cat.name}</span>
                    <ArrowRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all text-blue-500" />
                  </Link>
                ))}
              </div>
            </div>

            {/* CTA Widget */}
            <div className="rounded-[2.5rem] bg-gradient-to-br from-blue-600 to-indigo-700 p-8 text-center shadow-2xl shadow-blue-900/40 relative overflow-hidden group" data-aos="zoom-in">
              <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
              <ShieldCheck className="w-12 h-12 mx-auto text-blue-200 mb-6" />
              <h4 className="text-2xl font-extrabold mb-4">Zero Hassle Quotes</h4>
              <p className="text-blue-100/70 text-sm mb-8 leading-relaxed">
                Compare top insurance providers in under 2 minutes. No spam, just logic.
              </p>
              <button className="w-full bg-white text-blue-700 font-extrabold py-4 rounded-2xl hover:bg-slate-50 transition-all transform active:scale-95 shadow-xl">
                Get a Free Quote
              </button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default Home;
