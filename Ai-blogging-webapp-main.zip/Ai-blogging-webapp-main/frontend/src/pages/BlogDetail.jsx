import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, Tag, User, ArrowLeft, Loader2, Share2, Bookmark } from 'lucide-react';
import axios from 'axios';

const BlogDetail = () => {
  const { slug } = useParams();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const res = await axios.get(`/api/posts/${slug}`);
        setPost(res.data);
      } catch (err) {
        setError(err.response?.data?.message || 'Article not found');
      } finally {
        setLoading(false);
      }
    };

    fetchPost();
    if (window.AOS) window.AOS.init();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6">
        <div className="text-8xl mb-8 opacity-20">🔍</div>
        <h1 className="text-4xl font-extrabold text-white mb-4">Article Not Found</h1>
        <p className="text-slate-500 mb-10 text-center max-w-sm">{error || "The article you're looking for doesn't exist or has been moved."}</p>
        <Link to="/articles" className="btn-premium btn-premium-primary px-8 py-3">
          <ArrowLeft className="w-4 h-4" />
          Back to all articles
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <Link to="/articles" className="inline-flex items-center gap-2 text-slate-500 hover:text-blue-400 transition-colors mb-12 group" data-aos="fade-right">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-bold tracking-widest uppercase">Go Back</span>
        </Link>

        {/* Header Section */}
        <header className="mb-16" data-aos="fade-up">
          <div className="flex items-center gap-3 mb-6">
            <span className="px-3 py-1 rounded-full bg-blue-600/10 border border-blue-500/20 text-[10px] font-bold tracking-widest text-blue-400 uppercase">
              {post.category?.name || 'Insurance Policy'}
            </span>
          </div>
          
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white mb-8 leading-[1.15]">
            {post.title}
          </h1>

          <div className="flex flex-wrap items-center gap-8 py-6 border-y border-white/5">
            <div className="flex items-center gap-3">
              <img src={`https://i.pravatar.cc/40?u=${post.author_id}`} className="w-10 h-10 rounded-full border border-white/10" alt="Author" />
              <div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-0.5">Written By</p>
                <p className="text-sm font-bold text-white">Policy Expert</p>
              </div>
            </div>
            
            <div className="h-8 w-px bg-white/5 hidden sm:block"></div>

            <div>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-0.5">Published On</p>
              <p className="text-sm font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-500" />
                {new Date(post.createdAt || Date.now()).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </p>
            </div>

            <div className="ml-auto flex gap-2">
              <button className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:border-blue-500/30 hover:text-blue-400 transition-all">
                <Share2 className="w-4 h-4" />
              </button>
              <button className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:border-blue-500/30 hover:text-blue-400 transition-all">
                <Bookmark className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        {/* Featured Image */}
        {post.featuredImage && (
          <div className="rounded-[3rem] overflow-hidden mb-16 shadow-2xl shadow-blue-900/10 border border-white/5" data-aos="zoom-in">
            <img src={post.featuredImage} alt={post.title} className="w-full aspect-[2/1] object-cover" />
          </div>
        )}

        {/* Content Section */}
        <article className="glass-card rounded-[3rem] p-8 md:p-16 relative overflow-hidden" data-aos="fade-up">
          <div className="prose prose-invert prose-blue max-w-none 
              prose-headings:font-extrabold prose-headings:tracking-tight
              prose-p:text-slate-300 prose-p:leading-relaxed prose-p:text-lg
              prose-strong:text-white prose-a:text-blue-400 prose-a:font-bold
              prose-img:rounded-[2rem] prose-img:border prose-img:border-white/5
              prose-blockquote:border-l-4 prose-blockquote:border-blue-500 prose-blockquote:bg-blue-500/5 prose-blockquote:p-6 prose-blockquote:rounded-r-2xl prose-blockquote:italic
          ">
            <div dangerouslySetInnerHTML={{ __html: post.content }} />
          </div>

          {/* Floating Actions Sidebar (Simulated) */}
          <div className="mt-16 pt-16 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h4 className="text-xl font-bold mb-2">Did you find this helpful?</h4>
              <p className="text-slate-500 text-sm">Join 50k+ readers staying protected in the AI era.</p>
            </div>
            <div className="flex gap-4">
              <button className="btn-premium btn-premium-primary">Subscribe to Policy Hub</button>
              <button className="btn-premium btn-premium-glass">Share Insight</button>
            </div>
          </div>
        </article>
      </div>
    </div>
  );
};

export default BlogDetail;
