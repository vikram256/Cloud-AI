import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Tag, ChevronRight, Loader2, Search, Filter } from 'lucide-react';
import axios from 'axios';

const BlogListing = () => {
  const [posts, setPosts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [postsRes, categoriesRes] = await Promise.all([
          axios.get('/api/posts'),
          axios.get('/api/categories')
        ]);
        
        setPosts(Array.isArray(postsRes.data) ? postsRes.data.filter(p => p.status === 'published' || !p.status) : []);
        setCategories(Array.isArray(categoriesRes.data) ? categoriesRes.data : []);
      } catch (error) {
        console.error('Failed to fetch data', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredPosts = posts.filter(post => {
    const matchesCategory = selectedCategory ? (post.category?._id === selectedCategory || post.category?.slug === selectedCategory) : true;
    const matchesSearch = post.title?.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          post.excerpt?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-20" data-aos="fade-up">
          <h1 className="text-5xl lg:text-7xl font-extrabold tracking-tight mb-6">Article <span className="gradient-text">Collection.</span></h1>
          <p className="text-lg text-slate-400 leading-relaxed">Expert advice, industry news, and comprehensive guides to help you navigate the modern insurance landscape.</p>
        </div>

        {/* Filters & Search */}
        <div className="flex flex-col lg:flex-row gap-6 mb-16 items-start lg:items-center" data-aos="fade-up" data-aos-delay="100">
          <div className="relative w-full lg:max-w-md group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
            <input 
              type="text" 
              placeholder="Search articles..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-14 pl-14 pr-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-sm font-medium focus:bg-white/10"
            />
          </div>

          <div className="flex items-center gap-3 w-full lg:w-auto overflow-x-auto pb-2 scrollbar-none">
            <Filter className="w-4 h-4 text-slate-500 hidden sm:block flex-shrink-0" />
            <button
              onClick={() => setSelectedCategory('')}
              className={`px-6 py-3 rounded-full text-xs font-bold tracking-widest uppercase whitespace-nowrap transition-all border ${
                selectedCategory === '' 
                  ? 'bg-blue-600 border-blue-500 shadow-lg shadow-blue-900/40 text-white' 
                  : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/30'
              }`}
            >
              All Topics
            </button>
            {categories.map((category) => (
              <button
                key={category._id}
                onClick={() => setSelectedCategory(category._id)}
                className={`px-6 py-3 rounded-full text-xs font-bold tracking-widest uppercase whitespace-nowrap transition-all border ${
                  selectedCategory === category._id 
                    ? 'bg-blue-600 border-blue-500 shadow-lg shadow-blue-900/40 text-white' 
                    : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/30'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-32">
            <Loader2 className="w-12 h-12 animate-spin text-blue-500" />
          </div>
        ) : filteredPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, idx) => (
              <article key={post._id} className="glass-card rounded-[2.5rem] p-6 hover:-translate-y-2 transition-all group flex flex-col h-full relative overflow-hidden" data-aos="fade-up" data-aos-delay={idx * 50}>
                {post.featuredImage && (
                  <div className="relative h-56 -mx-2 -mt-2 mb-6 rounded-3xl overflow-hidden">
                    <img 
                      src={post.featuredImage} 
                      alt={post.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-transparent to-transparent opacity-60"></div>
                  </div>
                )}
                
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 rounded-full bg-blue-600/10 border border-blue-500/20 text-[10px] font-bold tracking-widest text-blue-400 uppercase">
                    {post.category?.name || 'Insurance'}
                  </span>
                  <span className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                    <Calendar className="w-3 h-3" />
                    {new Date(post.createdAt || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                </div>

                <h2 className="text-xl font-bold text-white mb-3 group-hover:text-blue-400 transition-colors line-clamp-2 leading-tight">
                  <Link to={`/article/${post.slug}`}>
                    {post.title}
                  </Link>
                </h2>

                <p className="text-slate-400 text-sm mb-8 line-clamp-3 leading-relaxed">
                  {post.excerpt || post.content?.replace(/<[^>]+>/g, '').substring(0, 150)}
                </p>

                <div className="mt-auto flex items-center justify-between pt-6 border-t border-white/5">
                  <div className="flex items-center gap-2">
                    <img src={`https://i.pravatar.cc/32?u=${post.author_id || idx}`} className="w-6 h-6 rounded-full border border-white/10" alt="Author" />
                    <span className="text-[10px] font-bold text-slate-400">Policy Expert</span>
                  </div>
                  <Link to={`/article/${post.slug}`} className="text-[10px] font-bold text-blue-400 uppercase tracking-widest flex items-center gap-1 group-hover:gap-2 transition-all">
                    Read Post <ChevronRight className="w-3 h-3" />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="text-center py-32 glass-card rounded-[3rem] border-white/5" data-aos="zoom-in">
            <Search className="w-12 h-12 text-slate-700 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-white mb-3">No articles found</h3>
            <p className="text-slate-400 max-w-md mx-auto">We couldn't find any articles matching your search or filter. Try a different topic or keyword!</p>
            <button 
              onClick={() => {setSearchQuery(''); setSelectedCategory('');}} 
              className="mt-8 px-6 py-2 rounded-full border border-blue-500/20 text-blue-400 font-bold text-xs tracking-widest uppercase hover:bg-blue-600 hover:text-white transition-all"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlogListing;
