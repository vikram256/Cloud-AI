import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, User, Lock, AlertCircle, Loader2, ArrowRight } from 'lucide-react';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (window.AOS) window.AOS.init();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    const result = await login(username, password);

    if (result.success) {
      if (result.user?.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/author/dashboard');
      }
    } else {
      setError(result.message);
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-20">
      <div className="max-w-md w-full" data-aos="fade-up">
        <div className="glass-card rounded-[3rem] p-10 border-white/5 relative overflow-hidden group">
          {/* Subtle Glow */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 blur-[60px] pointer-events-none group-hover:bg-blue-600/20 transition-colors"></div>
          
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center p-4 rounded-3xl bg-blue-600/10 border border-blue-500/20 mb-8">
              <ShieldCheck className="w-10 h-10 text-blue-500" />
            </div>
            <h1 className="text-4xl font-extrabold tracking-tight text-white mb-3">Platform Login</h1>
            <p className="text-slate-500 font-medium">InsureIQ AI-Era Dashboard Access</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="flex items-center gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-400 text-sm animate-in slide-in-from-top-2">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p className="font-medium">{error}</p>
              </div>
            )}

            {/* Username */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1">
                Username / Email
              </label>
              <div className="relative group/field">
                <User className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within/field:text-blue-500 transition-colors" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full h-16 pl-14 pr-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-slate-700 font-medium"
                  placeholder="admin or author@test.com"
                  autoComplete="username"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] ml-1">
                Security Password
              </label>
              <div className="relative group/field">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within/field:text-blue-500 transition-colors" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-16 pl-14 pr-6 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-slate-700 font-medium"
                  placeholder="••••••••"
                  autoComplete="current-password"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="btn-premium btn-premium-primary w-full h-16 text-base justify-center mt-4 group"
            >
              {isSubmitting ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <>
                  Enter Dashboard
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <p className="mt-12 text-center text-xs text-slate-600 font-mono tracking-widest">
            ENCRYPTED SESSION ACTIVE
          </p>
        </div>

        <div className="mt-8 text-center" data-aos="fade-up" data-aos-delay="200">
           <Link to="/" className="text-slate-500 hover:text-white text-xs font-bold uppercase tracking-widest transition-colors">
              ← Return to public site
           </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
