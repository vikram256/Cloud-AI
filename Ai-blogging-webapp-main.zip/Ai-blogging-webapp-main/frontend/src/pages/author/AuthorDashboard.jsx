import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import axios from 'axios';
import { io } from 'socket.io-client';
import { Loader2, UserCircle, Edit2, Trash2, Eye, BellRing, Settings, FileText, Plus, ChevronRight, Activity, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const AuthorDashboard = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSync, setLastSync] = useState('just now');
  const [stats, setStats] = useState({ total: 0, drafts: 0 });

  useEffect(() => {
    if (window.AOS) window.AOS.init();
    if (!user?._id) return;

    fetchPosts();

    const socket = io('/', { withCredentials: true });
    socket.emit('join_author_room', user._id);

    socket.on('post_updated', (updatedPost) => {
      setIsSyncing(true);
      setPosts(prev => {
        const exists = prev.find(p => p._id === updatedPost._id);
        if (exists) {
          return prev.map(p => p._id === updatedPost._id ? updatedPost : p);
        }
        return [updatedPost, ...prev];
      });
      setLastSync('just now');
      setTimeout(() => setIsSyncing(false), 2000);
    });

    socket.on('post_deleted', (deletedId) => {
      setPosts(prev => prev.filter(p => p._id !== deletedId));
    });

    return () => socket.disconnect();
  }, [user]);

  useEffect(() => {
    setStats({
      total: posts.length,
      drafts: posts.filter(p => p.status === 'draft').length
    });
  }, [posts]);

  const fetchPosts = async () => {
    try {
      const res = await axios.get('/api/posts');
      const authorPosts = res.data.filter(p => p.author_id === user._id);
      setPosts(authorPosts.reverse());
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    try {
      await axios.delete(`/api/posts/${id}`);
      setPosts(posts.filter(p => p._id !== id));
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen pt-16">
      {/* Sidebar Profile Card */}
      <aside className="w-80 bg-[#0A0A0F]/50 backdrop-blur-xl border-r border-white/5 hidden lg:block overflow-y-auto">
        <div className="p-8 pb-4 text-center border-b border-white/5" data-aos="fade-down">
          <div className="relative inline-block mb-6 group">
             <div className="w-24 h-24 rounded-[2rem] border-2 border-blue-500/20 bg-slate-800 p-0.5 group-hover:border-blue-500/50 transition-all overflow-hidden">
                {user.photo ? (
                  <img src={user.photo} className="w-full h-full object-cover rounded-[1.8rem]" alt="Profile" />
                ) : (
                  <UserCircle className="w-full h-full text-slate-700" />
                )}
             </div>
             <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 rounded-full border-4 border-[#0A0A0F] shadow-lg shadow-emerald-500/20"></div>
          </div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">{user?.name}</h2>
          <p className="text-blue-400 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">{user?.role} Access</p>
          <button className="mt-6 px-5 py-2 text-[10px] font-bold bg-white/5 border border-white/5 text-slate-400 rounded-full hover:bg-white/10 hover:text-white transition-all uppercase tracking-widest">
            Manage Credentials
          </button>
        </div>

        <div className="p-10 space-y-10" data-aos="fade-up">
          <div>
            <h3 className="text-[10px] font-bold text-slate-600 uppercase tracking-widest mb-6">Article Statistics</h3>
            <div className="space-y-4">
               <div className="glass-card p-5 rounded-2xl flex justify-between items-center border-blue-500/10">
                  <span className="text-xs font-bold text-slate-400">Total Publications</span>
                  <span className="text-2xl font-black text-white">{stats.total}</span>
               </div>
               <div className="glass-card p-5 rounded-2xl flex justify-between items-center border-amber-500/10">
                  <span className="text-xs font-bold text-slate-400">Draft Segments</span>
                  <span className="text-2xl font-black text-amber-500">{stats.drafts}</span>
               </div>
            </div>
          </div>

          <div className="pt-6 border-t border-white/5">
             <Link to="/admin/settings" className="flex items-center gap-3 text-xs font-bold text-slate-500 hover:text-white transition-colors uppercase tracking-widest">
                <Settings className="w-4 h-4" /> System Preferences
             </Link>
          </div>
        </div>
      </aside>

      {/* Main Stream Area */}
      <main className="flex-1 p-8 lg:p-14 overflow-y-auto">
         <div className="max-w-5xl mx-auto">
            
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12" data-aos="fade-right">
              <div>
                <div className="flex items-center gap-4 mb-2">
                  <Zap className={`w-5 h-5 ${isSyncing ? 'text-emerald-500 animate-pulse' : 'text-blue-500'}`} />
                  <h1 className="text-4xl font-extrabold text-white tracking-tight">Author <span className="gradient-text">Studio.</span></h1>
                </div>
                <p className="text-xs font-bold text-slate-500 tracking-[0.2em] flex items-center gap-2 uppercase">
                  <Activity className="w-3 h-3" /> 
                  Terminal Link Synchronized • last_check: {lastSync}
                </p>
              </div>
              
              <Link to="/admin/posts/new" className="btn-premium btn-premium-primary px-8 py-4 group">
                <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform" />
                Initialize New Publication
              </Link>
            </div>

            <div className="glass-card rounded-[3rem] border-white/5 overflow-hidden" data-aos="fade-up">
              {posts.length === 0 ? (
                <div className="text-center py-32 text-slate-600">
                  <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-8">
                     <FileText className="w-10 h-10 opacity-10" />
                  </div>
                  <p className="text-lg font-bold text-slate-500 mb-6">No active publications detected in your local sector.</p> 
                  <Link to="/admin/posts/new" className="btn-premium btn-premium-glass text-xs px-8 py-3 mx-auto">
                     Begin First Transmission
                  </Link>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-white/5 bg-white/[0.02]">
                        <th className="px-10 py-6 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Article Identifier</th>
                        <th className="px-10 py-6 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Category Vertical</th>
                        <th className="px-10 py-6 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Deployment State</th>
                        <th className="px-10 py-6 text-right text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Operations</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {posts.map((post, idx) => (
                        <tr key={post._id} className="hover:bg-white/[0.03] transition-colors group" data-aos="fade-up" data-aos-delay={idx * 50}>
                          <td className="px-10 py-8">
                            <Link to={`/admin/posts/${post._id}/edit`} className="block font-extrabold text-white group-hover:text-blue-400 transition-colors text-lg mb-1">
                              {post.title}
                            </Link>
                            <div className="text-[10px] font-mono font-bold text-slate-600 uppercase tracking-widest">Modified: {new Date(post.updatedAt || post.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</div>
                          </td>
                          <td className="px-10 py-8">
                            <span className="px-4 py-1.5 rounded-full bg-blue-600/10 border border-blue-500/20 text-blue-400 text-[10px] font-bold uppercase tracking-widest">
                               {post.category?.name || 'General Policy'}
                            </span>
                          </td>
                          <td className="px-10 py-8">
                            <div className={`flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest ${post.status === 'published' ? 'text-emerald-500' : 'text-amber-500'}`}>
                               <div className={`w-1.5 h-1.5 rounded-full ${post.status === 'published' ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`}></div>
                               {post.status}
                            </div>
                          </td>
                          <td className="px-10 py-8 text-right">
                             <div className="flex justify-end gap-3">
                                <Link to={`/admin/posts/${post._id}/edit`} className="p-3 bg-white/5 border border-white/5 rounded-xl text-slate-400 hover:text-blue-400 hover:border-blue-500/30 transition-all shadow-sm">
                                   <Edit2 className="w-4 h-4" />
                                </Link>
                                {post.status === 'published' && (
                                   <Link to={`/article/${post.slug}`} className="p-3 bg-white/5 border border-white/5 rounded-xl text-slate-400 hover:text-white hover:border-white/20 transition-all shadow-sm">
                                      <Eye className="w-4 h-4" />
                                   </Link>
                                )}
                                <button onClick={() => handleDelete(post._id)} className="p-3 bg-white/5 border border-white/5 rounded-xl text-slate-400 hover:text-red-400 hover:border-red-500/30 transition-all shadow-sm">
                                   <Trash2 className="w-4 h-4" />
                                </button>
                             </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="mt-12 flex items-center justify-center gap-3">
               <BellRing className="w-4 h-4 text-slate-700" />
               <p className="text-[10px] font-bold text-slate-700 uppercase tracking-[0.2em]">Real-time synchronization active via Socket.io Encryption</p>
            </div>
         </div>
      </main>
    </div>
  );
};

export default AuthorDashboard;
