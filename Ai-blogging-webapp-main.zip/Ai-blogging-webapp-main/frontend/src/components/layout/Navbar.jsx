import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, Menu, X, LogOut, User as UserIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 h-16 z-[1000] border-b transition-all duration-300 ${
      isScrolled 
        ? 'bg-[#0A0A0F]/90 backdrop-blur-xl border-[#3B82F6]/10 py-0' 
        : 'bg-transparent border-transparent py-2'
    }`}>
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-600/20 group-hover:border-blue-600/50 transition-colors">
            <ShieldCheck className="w-6 h-6 text-blue-500" />
          </div>
          <span className="font-bold text-xl tracking-tight text-white">InsureIQ</span>
        </Link>

        {/* Desktop Links */}
        <ul className="hidden md:flex items-center gap-8">
          <li>
            <Link to="/" className="text-sm font-medium text-slate-400 hover:text-white transition-colors relative group">
              Home
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-500 transition-all group-hover:w-full"></span>
            </Link>
          </li>
          <li>
            <Link to="/articles" className="text-sm font-medium text-slate-400 hover:text-white transition-colors relative group">
              Explore
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-500 transition-all group-hover:w-full"></span>
            </Link>
          </li>
          <li>
            <Link to="/about" className="text-sm font-medium text-slate-400 hover:text-white transition-colors relative group">
              About
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-500 transition-all group-hover:w-full"></span>
            </Link>
          </li>
        </ul>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-3 pl-4 border-l border-white/10">
              <div className="hidden sm:flex flex-col items-end mr-1">
                <span className="text-xs font-bold text-white leading-none">{user.name}</span>
                <span className="text-[10px] text-blue-400 font-medium uppercase tracking-widest">{user.role}</span>
              </div>
              <Link
                to={user.role === 'admin' ? '/admin' : '/author/dashboard'}
                className="h-9 w-9 rounded-full bg-blue-600/10 border border-blue-600/20 flex items-center justify-center hover:border-blue-600/50 transition-colors"
                title="Go to Dashboard"
              >
                <UserIcon className="w-4 h-4 text-blue-400" />
              </Link>
              <button 
                onClick={handleLogout}
                className="p-2 text-slate-500 hover:text-red-400 transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="px-5 py-2 rounded-full border border-white/10 bg-white/5 text-sm font-semibold text-white hover:bg-white/10 hover:border-blue-500/50 transition-all active:scale-95"
            >
              Admin Login
            </Link>
          )}

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden p-2 text-slate-400 hover:text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[#0F0F1A]/95 backdrop-blur-2xl border-b border-white/5 p-4 animate-in fade-in slide-in-from-top-4">
          <ul className="space-y-4">
            <li><Link to="/" onClick={() => setIsMenuOpen(false)} className="block text-white font-medium">Home</Link></li>
            <li><Link to="/articles" onClick={() => setIsMenuOpen(false)} className="block text-white font-medium">Explore</Link></li>
            <li><Link to="/about" onClick={() => setIsMenuOpen(false)} className="block text-white font-medium">About</Link></li>
            {!user && (
              <li><Link to="/login" onClick={() => setIsMenuOpen(false)} className="block text-blue-400 font-bold mt-4">Login</Link></li>
            )}
          </ul>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
