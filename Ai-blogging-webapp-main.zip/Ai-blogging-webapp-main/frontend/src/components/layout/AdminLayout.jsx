import { Outlet, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, FileText, Database, Settings, Users, ShieldCheck, ChevronRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const AdminLayout = () => {
  const { user } = useAuth();
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path || (location.pathname.startsWith(path) && path !== '/admin');
  };

  const menuItems = [
    { 
      path: user.role === 'admin' ? '/admin' : '/author/dashboard', 
      label: user.role === 'admin' ? 'Overview' : 'My Dashboard', 
      icon: LayoutDashboard 
    },
    { 
      path: '/admin/posts', 
      label: user.role === 'admin' ? 'Articles' : 'My Articles', 
      icon: FileText 
    },
    ...(user.role === 'admin' ? [
      { path: '/admin/categories', label: 'Categories', icon: Database },
      { path: '/admin/authors', label: 'Authors', icon: Users },
      { path: '/admin/settings', label: 'Settings', icon: Settings },
    ] : [])
  ];

  return (
    <div className="flex h-[calc(100vh-4rem)] pt-16 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 flex-shrink-0 bg-[#0A0A0F]/50 backdrop-blur-xl border-r border-white/5 overflow-y-auto hidden lg:block">
        <div className="py-10 px-6">
          <div className="flex items-center gap-3 mb-12 px-2">
            <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-none mb-1">Authenticated</p>
              <h3 className="text-sm font-bold text-white uppercase tracking-tighter capitalize">{user.role} Panel</h3>
            </div>
          </div>

          <nav className="space-y-2">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center justify-between px-5 py-4 rounded-2xl transition-all group ${
                  isActive(item.path)
                    ? 'bg-blue-600/10 border border-blue-500/20 text-white shadow-[0_0_20px_rgba(59,130,246,0.1)]'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                <div className="flex items-center">
                  <item.icon className={`mr-4 h-5 w-5 transition-colors ${isActive(item.path) ? 'text-blue-500' : 'text-slate-500 group-hover:text-slate-300'}`} />
                  <span className="text-sm font-semibold tracking-tight">{item.label}</span>
                </div>
                {isActive(item.path) && <ChevronRight className="w-4 h-4 text-blue-500" />}
              </Link>
            ))}
          </nav>
        </div>

        {/* Footer Info */}
        <div className="absolute bottom-10 left-6 right-6 p-6 rounded-3xl bg-white/5 border border-white/5">
           <p className="text-[10px] font-bold text-slate-600 uppercase tracking-[0.2em] mb-2">Platform Version</p>
           <p className="text-xs font-bold text-slate-400 uppercase">2026.1.0 AI-ERA</p>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-blue-600/20">
        <div className="max-w-6xl mx-auto p-8 lg:p-12 min-h-full">
           <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AdminLayout;
