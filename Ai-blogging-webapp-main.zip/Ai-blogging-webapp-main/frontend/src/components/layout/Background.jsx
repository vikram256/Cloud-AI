import { useEffect } from 'react';

const Background = () => {
  useEffect(() => {
    if (window.tsParticles) {
      window.tsParticles.load("tsparticles", {
        background: { color: { value: "transparent" } },
        fpsLimit: 60,
        particles: {
          number: { value: 60, density: { enable: true, area: 800 } },
          color: { value: ["#3B82F6", "#8B5CF6", "#06B6D4"] },
          opacity: { value: 1, random: true },
          size: { value: { min: 1, max: 1.5 } },
          links: {
            enable: true,
            distance: 130,
            color: "#3B82F6",
            opacity: 0.1,
            width: 1
          },
          move: {
            enable: true,
            speed: 0.4,
            direction: "none",
            random: true,
            outModes: "bounce"
          }
        },
        interactivity: {
          events: {
            onHover: { enable: true, mode: "repulse" },
            onClick: { enable: false }
          },
          modes: {
            repulse: { distance: 80, duration: 0.4 }
          }
        }
      });
    }
  }, []);

  return (
    <>
      <div id="tsparticles" style={{ position: 'fixed', inset: 0, zIndex: -1 }}></div>
      <div className="grid-overlay"></div>
      <div className="orb orb-1"></div>
      <div className="orb orb-2"></div>
    </>
  );
};

export default Background;
