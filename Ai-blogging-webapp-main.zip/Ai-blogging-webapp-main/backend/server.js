import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { createServer } from "http";
import { Server } from "socket.io";
import cookieParser from "cookie-parser";

import mongoose from "mongoose";

// Load env variables
dotenv.config();

// Connect to MongoDB Atlas
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB Atlas'))
  .catch(err => console.error('❌ MongoDB Connection Error:', err));

// Initialize express & socket.io
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:5174",
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true
  }
});

app.set('io', io);

io.on('connection', (socket) => {
  console.log('Socket client connected:', socket.id);
  
  // Join a personal author room
  socket.on('join_author_room', (authorId) => {
    socket.join(`author_${authorId}`);
    console.log(`Socket joined room: author_${authorId}`);
  });

  socket.on('disconnect', () => {
    console.log('Socket client disconnected');
  });
});

// Middleware
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5174", credentials: true }));
app.use(express.json());
app.use(cookieParser());
app.use('/uploads', express.static('uploads'));

import authRoutes from "./routes/authRoutes.js";
import categoryRoutes from "./routes/categoryRoutes.js";
import postRoutes from "./routes/postRoutes.js";
import authorRoutes from "./routes/authorRoutes.js";
import resetRoutes from "./routes/resetRoutes.js";

// Basic route
app.get("/", (req, res) => {
  res.send("Insurance Blog API is running...");
});

// Mount Routes
app.use("/api/auth", authRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/posts", postRoutes);
app.use("/api/authors", authorRoutes);
app.use("/admin/reset", resetRoutes);

// Setup Port
const PORT = process.env.PORT || 5000;
httpServer.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
