import express from 'express';
import { resetPlatform } from '../controllers/resetController.js';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/', protect, admin, resetPlatform);

export default router;
