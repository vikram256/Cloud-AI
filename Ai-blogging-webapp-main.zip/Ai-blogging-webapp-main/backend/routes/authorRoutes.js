import express from 'express';
import multer from 'multer';
import { getAuthors, getAuthorById, createAuthor, updateAuthor, deleteAuthor, getAuthorPosts } from '../controllers/authorController.js';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, uniqueSuffix + '-' + file.originalname)
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Only images are allowed'));
  }
});

router.route('/')
  .get(getAuthors)
  .post(protect, admin, upload.single('photo'), createAuthor);

router.route('/:id')
  .get(getAuthorById)
  .put(protect, admin, upload.single('photo'), updateAuthor)
  .delete(protect, admin, deleteAuthor);

router.route('/:id/posts')
  .get(getAuthorPosts);

export default router;
