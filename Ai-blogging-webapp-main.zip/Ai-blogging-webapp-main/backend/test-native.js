import { MongoClient } from 'mongodb';
import dotenv from 'dotenv';
dotenv.config();

async function test() {
  const uri = process.env.MONGO_URI;
  const client = new MongoClient(uri, { 
    serverSelectionTimeoutMS: 10000 
  });

  try {
    console.log('Connecting with Native Driver...');
    await client.connect();
    console.log('Connected Successfully with Native Driver!');
    const dbs = await client.db().admin().listDatabases();
    console.log('Databases:', dbs.databases.map(d => d.name));
    process.exit(0);
  } catch (err) {
    console.error('Native Driver Test Failed:', err.message);
    if (err.reason) {
      console.log('Error Reason:', JSON.stringify(err.reason, null, 2));
    }
    process.exit(1);
  } finally {
    await client.close();
  }
}

test();
