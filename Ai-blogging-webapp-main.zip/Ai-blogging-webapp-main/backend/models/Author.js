import mongoose from 'mongoose';

const AuthorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  bio: { type: String },
  photo: { type: String },
  password: { type: String }, // For author dashboard access
  role: { type: String, default: 'author' },
  status: { type: String, default: 'active' },
}, { timestamps: true });

export default mongoose.model('Author', AuthorSchema);
