import mongoose from 'mongoose';

const PostSchema = new mongoose.Schema({
  title: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  content: { type: String, required: true },
  excerpt: { type: String },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  author_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Author', required: true },
  status: { type: String, default: 'draft', enum: ['draft', 'published'] },
  featuredImage: { type: String },
}, { timestamps: true });

export default mongoose.model('Post', PostSchema);
