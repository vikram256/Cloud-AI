import Author from '../models/Author.js';
import Post from '../models/Post.js';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

// @desc    Get all authors
// @route   GET /api/authors
// @access  Public
export const getAuthors = async (req, res) => {
  try {
    const authors = await Author.find({});
    res.json(authors);
  } catch (error) {
    res.status(500).json({ message: "Error fetching authors" });
  }
};

// @desc    Get author by ID with their posts
// @route   GET /api/authors/:id
// @access  Public
export const getAuthorById = async (req, res) => {
  try {
    const author = await Author.findById(req.params.id);
    if (!author) return res.status(404).json({ message: 'Author not found' });
    
    const authorPosts = await Post.find({ author_id: author._id });
    res.json({ ...author._doc, posts: authorPosts });
  } catch (error) {
    res.status(404).json({ message: 'Author not found' });
  }
};

// @desc    Create new author with photo upload
export const createAuthor = async (req, res) => {
  try {
    const { name, email, bio, role, status, password } = req.body;
    if (!name || !email) return res.status(400).json({ message: 'Name and email are required' });

    const exists = await Author.findOne({ email });
    if (exists) {
      return res.status(400).json({ message: 'Email already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password || 'author123', salt);

    const photo = req.file ? `/uploads/${req.file.filename}` : null;

    const author = await Author.create({
      name,
      email,
      bio,
      photo,
      password: hashedPassword,
      role: role || 'author',
      status: status || 'active',
    });

    res.status(201).json(author);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Update author profile
export const updateAuthor = async (req, res) => {
  try {
    const author = await Author.findById(req.params.id);
    if (!author) return res.status(404).json({ message: 'Author not found' });

    const { name, email, bio, role, status, password } = req.body;
    
    if (email && email !== author.email) {
      const exists = await Author.findOne({ email });
      if (exists) return res.status(400).json({ message: 'Email already exists' });
    }

    if (req.file) {
      if (author.photo && author.photo.startsWith('/uploads/')) {
        const oldPath = path.join(process.cwd(), author.photo);
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      }
      author.photo = `/uploads/${req.file.filename}`;
    }

    if (name) author.name = name;
    if (email) author.email = email;
    if (bio !== undefined) author.bio = bio;
    if (role) author.role = role;
    if (status) author.status = status;
    
    if (password) {
       const salt = await bcrypt.genSalt(10);
       author.password = await bcrypt.hash(password, salt);
    }

    const updatedAuthor = await author.save();
    res.json(updatedAuthor);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Delete author and handle assets/posts
export const deleteAuthor = async (req, res) => {
  try {
    const author = await Author.findById(req.params.id);
    if (!author) return res.status(404).json({ message: 'Author not found' });

    await Post.updateMany({ author_id: author._id }, { author_id: null });

    if (author.photo && author.photo.startsWith('/uploads/')) {
      const oldPath = path.join(process.cwd(), author.photo);
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    }

    await author.deleteOne();
    res.json({ message: 'Author deleted and posts unassigned' });
  } catch (error) {
    res.status(404).json({ message: 'Author not found' });
  }
};

// @desc    Get all posts by author ID
export const getAuthorPosts = async (req, res) => {
  try {
    const posts = await Post.find({ author_id: req.params.id });
    res.json(posts);
  } catch (error) {
    res.status(404).json({ message: 'Author not found' });
  }
};
