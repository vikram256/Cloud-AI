import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import Author from '../models/Author.js';

// @desc    Basic login - check username & password
// @route   POST /api/auth/login
// @access  Public
export const authUser = async (req, res) => {
  try {
    const { username, password } = req.body;

    const adminUsername = process.env.ADMIN_USERNAME || 'admin';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';

    // Case-insensitive comparisons for username/email
    const normalizedUsername = username?.toLowerCase().trim();

    if (normalizedUsername === adminUsername && password === adminPassword) {
      const token = jwt.sign({ userId: '60c72b2f9b1d8b001c8e4f1a', role: 'admin' }, process.env.JWT_SECRET || 'local_secret_key', {
        expiresIn: '30d',
      });

      res.cookie('jwt', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production', 
        sameSite: 'lax',
        maxAge: 30 * 24 * 60 * 60 * 1000, 
      });

      res.json({
        success: true,
        user: {
          name: "Admin",
          username: adminUsername,
          role: "admin",
          _id: '60c72b2f9b1d8b001c8e4f1a',
        },
      });
      return;
    } 

    // Check for author login in MongoDB
    const author = await Author.findOne({ email: normalizedUsername });
    if (author && (await bcrypt.compare(password, author.password))) {
      const token = jwt.sign({ userId: author._id, role: author.role }, process.env.JWT_SECRET || 'local_secret_key', {
        expiresIn: '30d',
      });

      res.cookie('jwt', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production', 
        sameSite: 'lax',
        maxAge: 30 * 24 * 60 * 60 * 1000, 
      });

      res.json({
        success: true,
        user: {
          name: author.name,
          username: author.email,
          role: author.role,
          _id: author._id,
        },
      });
      return;
    }

    res.status(401).json({ success: false, message: "Invalid username or password" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server auth error" });
  }
};

// @desc    Logout
// @route   POST /api/auth/logout
// @access  Public
export const logoutUser = (req, res) => {
  res.cookie('jwt', '', {
    httpOnly: true,
    expires: new Date(0),
  });
  res.status(200).json({ success: true, message: "Logged out successfully" });
};
