import Category from '../models/Category.js';
import Author from '../models/Author.js';
import Post from '../models/Post.js';
import fs from 'fs';
import path from 'path';

export const resetPlatform = async (req, res) => {
  try {
    // 1. Wipe Collections
    await Category.deleteMany({});
    await Author.deleteMany({});
    await Post.deleteMany({});

    // 2. Clear uploads folder
    const uploadsDir = path.join(process.cwd(), 'uploads');
    if (fs.existsSync(uploadsDir)) {
      const files = fs.readdirSync(uploadsDir);
      for (const file of files) {
        if (file !== '.gitkeep') {
          fs.unlinkSync(path.join(uploadsDir, file));
        }
      }
    } else {
      fs.mkdirSync(uploadsDir);
    }

    // 3. Re-seed Default Categories
    const defaults = [
      { name: 'Life Insurance', slug: 'life-insurance', description: 'Life Insurance coverage' },
      { name: 'Health Insurance', slug: 'health-insurance', description: 'Health coverage topics' },
      { name: 'Auto Insurance', slug: 'auto-insurance', description: 'Auto Insurance' },
      { name: 'Home Insurance', slug: 'home-insurance', description: 'Home policies' },
      { name: 'Business Insurance', slug: 'business-insurance', description: 'Business policies' }
    ];
    await Category.insertMany(defaults);

    res.json({ success: true, message: "Production Database reset to clean state with global defaults." });
  } catch (error) {
    console.error('Reset Error:', error);
    res.status(500).json({ success: false, message: 'Hard Reset Protocol failed on database level.' });
  }
};
