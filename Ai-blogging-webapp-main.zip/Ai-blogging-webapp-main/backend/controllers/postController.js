import Post from '../models/Post.js';
import Category from '../models/Category.js';

// @desc    Get all posts
// @route   GET /api/posts
// @access  Public
export const getPosts = async (req, res) => {
  try {
    const posts = await Post.find({})
      .populate('category')
      .populate('author_id', 'name photo bio')
      .sort({ createdAt: -1 });
    res.json(posts);
  } catch (error) {
    res.status(500).json({ message: "Error fetching posts" });
  }
};

// @desc    Get single post by ID or Slug
// @route   GET /api/posts/:id
// @access  Public
export const getPostById = async (req, res) => {
  try {
    const post = await Post.findOne({ $or: [{ _id: req.params.id }, { slug: req.params.id }] })
      .populate('category')
      .populate('author_id', 'name photo bio');
    
    if (post) {
      res.json(post);
    } else {
      res.status(404).json({ message: "Post not found" });
    }
  } catch (error) {
    res.status(404).json({ message: "Post not found" });
  }
};

// @desc    Create new post
export const createPost = async (req, res) => {
  try {
    const { title, content, excerpt, featuredImage, category, status } = req.body;
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    
    const exists = await Post.findOne({ slug });
    if (exists) {
      return res.status(400).json({ message: "A post with this title already exists" });
    }

    const post = await Post.create({
      title,
      slug,
      content,
      excerpt,
      featuredImage,
      category,
      status: status || 'draft',
      author_id: req.user?._id || null,
    });

    const populatedPost = await post.populate(['category', { path: 'author_id', select: 'name photo bio' }]);
    
    // Emit real-time update
    const io = req.app.get('io');
    if (io && post.author_id) {
      io.to(`author_${post.author_id}`).emit('post_updated', populatedPost);
    }

    res.status(201).json(populatedPost);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Update existing post
export const updatePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const { title, content, excerpt, featuredImage, category, status } = req.body;

    if (title && title !== post.title) {
      post.title = title;
      post.slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    }
    
    if (content) post.content = content;
    if (excerpt !== undefined) post.excerpt = excerpt;
    if (featuredImage !== undefined) post.featuredImage = featuredImage;
    if (category) post.category = category;
    if (status) post.status = status;

    const updatedPost = await post.save();
    const populatedPost = await updatedPost.populate(['category', { path: 'author_id', select: 'name photo bio' }]);

    const io = req.app.get('io');
    if (io && post.author_id) {
      io.to(`author_${post.author_id}`).emit('post_updated', populatedPost);
    }

    res.json(populatedPost);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Delete post
export const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const deletedId = post._id;
    const authorId = post.author_id;
    
    await post.deleteOne();
    
    const io = req.app.get('io');
    if (io && authorId) {
      io.to(`author_${authorId}`).emit('post_deleted', deletedId);
    }
    
    res.json({ message: "Post removed" });
  } catch (error) {
    res.status(404).json({ message: "Post not found" });
  }
};
