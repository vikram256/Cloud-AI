import jwt from "jsonwebtoken";

export const protect = async (req, res, next) => {
  let token = req.cookies.jwt;

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'local_secret_key');
      // Since auth is hardcoded in .env, we just mock the user object
      req.user = {
        _id: decoded.userId || '60c72b2f9b1d8b001c8e4f1a',
        role: decoded.role || 'admin',
        name: "Admin",
      };
      next();
    } catch (error) {
      console.error(error);
      res.status(401).json({ message: "Not authorized, token failed" });
    }
  } else {
    res.status(401).json({ message: "Not authorized, no token" });
  }
};

export const admin = (req, res, next) => {
  if (req.user && req.user.role === "admin") {
    next();
  } else {
    res.status(401).json({ message: "Not authorized as an admin" });
  }
};
