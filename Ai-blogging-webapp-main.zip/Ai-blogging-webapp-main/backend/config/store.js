export let data = {
  authors: [
    { _id: 'author_sample', name: 'Sample Author', email: 'author@test.com', slug: 'sample-author', bio: 'A sample author for testing.', role: 'author', status: 'active', created_at: new Date() }
  ],
  categories: [
    { _id: 'cat1', name: 'Life Insurance', slug: 'life-insurance', description: 'Life Insurance coverage' },
    { _id: 'cat2', name: 'Health Insurance', slug: 'health-insurance', description: 'Health coverage topics' },
    { _id: 'cat3', name: 'Auto Insurance', slug: 'auto-insurance', description: 'Auto Insurance' },
    { _id: 'cat4', name: 'Home Insurance', slug: 'home-insurance', description: 'Home policies' },
    { _id: 'cat5', name: 'Business Insurance', slug: 'business-insurance', description: 'Business policies' }
  ],
  posts: []
};

export const resetStore = () => {
  data.authors = [];
  data.posts = [];
  data.categories = [
    { _id: 'cat1', name: 'Life Insurance', slug: 'life-insurance', description: 'Life Insurance coverage' },
    { _id: 'cat2', name: 'Health Insurance', slug: 'health-insurance', description: 'Health coverage topics' },
    { _id: 'cat3', name: 'Auto Insurance', slug: 'auto-insurance', description: 'Auto Insurance' },
    { _id: 'cat4', name: 'Home Insurance', slug: 'home-insurance', description: 'Home policies' },
    { _id: 'cat5', name: 'Business Insurance', slug: 'business-insurance', description: 'Business policies' }
  ];
};
