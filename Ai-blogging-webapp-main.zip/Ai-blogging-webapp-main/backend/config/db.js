import mongoose from "mongoose";

const connectDB = async () => {
  try {
    const maskedUri = process.env.MONGO_URI?.replace(/:([^:@]+)@/, ':****@');
    console.log(`Attempting to connect to: ${maskedUri}`);
    
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 10000, // 10s timeout
    });
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Database Connection Error: ${error.message}`);
    // console.error(error.stack);
    process.exit(1);
  }
};

export default connectDB;
