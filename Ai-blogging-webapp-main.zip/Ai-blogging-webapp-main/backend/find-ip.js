async function getIP() {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    console.log('-----------------------------------------');
    console.log('YOUR SERVER IP IS:', data.ip);
    console.log('Please add THIS IP to your MongoDB Atlas Network Access.');
    console.log('-----------------------------------------');
  } catch (error) {
    console.error('Could not fetch IP:', error.message);
  }
}

getIP();
