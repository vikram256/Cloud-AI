# InsureIQ: Premium AI-Era Insurance Blog Platform 🚀

A high-Performance, production-ready MERN stack blog platform designed for the modern insurance industry.

## 🌟 Key Features
- **AI-Era Design**: High-impact glassmorphism UI with AOS (Animate On Scroll) and tsParticles.
- **Micro-Dashboard Architecture**: Specialized dashboards for both Admins and Authors.
- **Real-Time Synchronization**: Live post updates and deletions powered by Socket.io.
- **Persistent Data Matrix**: Integrated with MongoDB Atlas for secure cloud storage.
- **Production-Ready Hosting**: Pre-configured for seamless Netlify (frontend) and Render (backend).

## 🛠️ Technology Stack
- **Frontend**: React (Vite), Tailwind CSS, Lucide Icons, React Quill.
- **Backend**: Node.js, Express, Socket.io, Mongoose (MongoDB).
- **Security**: JWT & HttpOnly cookies, Bcryptjs password hashing.
- **Animations**: AOS, tsParticles, CountUp.js.

## 🚀 Getting Started

### 1. Prerequisites
- Node.js (v18+)
- MongoDB Atlas Account

### 2. Installations
```bash
# Clone the repository
git clone https://github.com/your-username/insureiq.git

# Install all dependencies (Root, Backend, Frontend)
npm run install-all
```

### 3. Environment Configuration
Create a `.env` file in the `/backend` directory:
```env
MONGO_URI=your_mongodb_atlas_uri
JWT_SECRET=your_secure_random_key
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
CLIENT_URL=http://localhost:5174
```

### 4. Run Development
```bash
npm run dev
```

## 📋 Platform Deployment

### Frontend (Netlify)
1. Set the build command to `npm run build`.
2. Set the publish directory to `dist`.
3. Add the `BACKEND_URL` environment variable.

### Backend (Render)
1. Add your `.env` variables in the dashboard.
2. Set the start command to `npm start`.

---
*Created with ♥ for the Insurance Industry.*
